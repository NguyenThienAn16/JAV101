package Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/bai1them")
public class Bai1them extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		req.getRequestDispatcher("Bai1them.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		float a, b, kq;
		a = Float.parseFloat(req.getParameter("txta").toString());
		b = Float.parseFloat(req.getParameter("txtb").toString());
		kq = a + b;
		req.setAttribute("kq", kq);
		req.getRequestDispatcher("Bai1them.jsp").forward(req, resp);

	}
}
