package Controller;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/bai4", "/crud/create", "/crud/update", "/crud/delete"})

public class Bai4controller extends HttpServlet{
private static final long serialVersionUID = 1L;
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String uri = req.getRequestURI();
	resp.setContentType("text/html;charset=UTF-8");
	if(uri.contains("/crud/create"))
		resp.getWriter().println("<h2>Creating a new record...</h2>");
	else if (uri.endsWith("/crud/update"))
		resp.getWriter().println("<h2>Update an existing record...</h2>");
	else if (uri.endsWith("/crud/delete"))
		resp.getWriter().println("<h2>Delete a record...</h2>");
	else 
		resp.getWriter().println("<a href=\"bai1\">Bai 1</a>||\r\n"
				+ "<a href=\"bai2\">Bai 2</a>||\r\n"
				+ "<a href=\"bai3\">Bai 3</a>||\r\n"
				+ "<a href=\"bai4\">Bai 4</a>\r\n"
				+ "<hr/>\r\n"
				+ "<a href=\"crud/create\"><button>Create</button></a>\r\n"
				+ "<a href=\"crud/update\"><button>Update</button></a>\r\n"
				+ "<a href=\"crud/delete\"><button>Delete</button></a>");

}
}
