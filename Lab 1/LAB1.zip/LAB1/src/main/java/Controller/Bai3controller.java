package Controller;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai3")

public class Bai3controller extends HttpServlet{
private static final long serialVersionUID = 1L;
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        resp.setContentType("text/html;charset=UTF-8");
	        resp.getWriter().append("<h2>THÔNG TIN URL</h2>");
	        resp.getWriter().append("<ul>");
	        resp.getWriter().append("<li><b>URL:</b> " + req.getRequestURL() + "</li>");
	        resp.getWriter().append("<li><b>URI:</b> " + req.getRequestURI() + "</li>");
	        resp.getWriter().append("<li><b>QueryString:</b> " + req.getQueryString() + "</li>");
	        resp.getWriter().append("<li><b>ServletPath:</b> " + req.getServletPath() + "</li>");
	        resp.getWriter().append("<li><b>ContextPath:</b> " + req.getContextPath() + "</li>");
	        resp.getWriter().append("<li><b>PathInfo:</b> " + req.getPathInfo() + "</li>");
	        resp.getWriter().append("<li><b>Method:</b> " + req.getMethod() + "</li>");
	        resp.getWriter().append("</ul>");
	    }

	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
	        doGet(req, resp);
	    }
	}
